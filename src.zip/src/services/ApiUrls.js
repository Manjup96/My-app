const BASE_URL = "https://iiiqbets.com/";

export const TENANAT_LOGIN_URL = `${BASE_URL}/pg-management/TENANT-login-API-managers-buildings.php`;

export const TENANAT_NEWS_URL = `${BASE_URL}/pg-management/NEWS-GET-API-manager-bulding.php`;

export const TENANAT_COMPLAINT_URL = `${BASE_URL}/pg-management/Complaints-GET-API-managers-buildings.php`

export const TENANAT_COMPLAINT_UPDATE_URL = `${BASE_URL}/pg-management/update-Complaints-API.php`

export const TENANAT_COMPLAINT_DELETE_URL = `${BASE_URL}/pg-management/delete-Complaints-API.php`

export const TENANT_MEALS_POST_URL = `${BASE_URL}/pg-management/MEALS-POST-by-tenant-API.php`

export const TENANT_MEALS_GET_URL = `${BASE_URL}/pg-management/GET-Meals-for-tenant-API.php`

export const TENANT_MEALS_UPDATE_URL=`${BASE_URL}/pg-management/update-Meals-API.php`

export const TENANT_MEALS_Edit_URL=`${BASE_URL}/pg-management/GET-Meals-for-tenant-API.php`

export const TENANT_MEALS_DELETE_URL=`${BASE_URL}/pg-management/delete-Meals-API.php`
